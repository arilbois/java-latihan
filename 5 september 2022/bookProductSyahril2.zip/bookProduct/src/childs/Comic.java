package childs;

import parent.BookProduct;
import parent.Person;
public class Comic extends Book {
    boolean volumeSeries;
    Mangaka mangaka;
    //Construktor
    public Comic(String bookCode, String title, Mangaka mangaka, Publisher publisher, boolean volumeSeries) {
        super(bookCode, title, mangaka, publisher);
        this.volumeSeries = volumeSeries;
        this.mangaka = mangaka;
        calculatePrice();
    }
    private void calculatePrice() {
        double percen;
        if (mangaka.getRating().equalsIgnoreCase("New Commer") && volumeSeries) {
            percen = 1.35;
        }else if (mangaka.getRating().equalsIgnoreCase("New Commer") && !volumeSeries) {
            percen = 1.25;
        }else if(mangaka.getRating().equalsIgnoreCase("Good") && volumeSeries){
            percen = 1.45;
        }else if(mangaka.getRating().equalsIgnoreCase("Good") && !volumeSeries){
            percen = 1.3;
        }else if(mangaka.getRating().equalsIgnoreCase("Best Seller") && volumeSeries){
            percen = 1.5;
        }else{
            percen = 1.4;
        }
        this.setPrice(getPublisher().getProductionCost() * percen);
    }
    public void getDetailComic(String author, String publisher) {
        String series;
        if(volumeSeries){
            series = "Available";
        }else{
            series = "Not Available";
        }
        System.out.println("Mangaka          : "+author);
        System.out.println("Book Code        : "+getBookCode());
        System.out.println("Title            : "+getTitle());
        System.out.println("Rating           : "+mangaka.getRating());
        System.out.println("Publiser         : "+publisher);
        System.out.println("Price            : "+indonesiaCurrency());
        System.out.println("location         : "+getPerson().getCountry());
        System.out.println("Series           : "+series);
        System.out.println("===================================");
    }

    @Override
    public String toString() {
        return "Volume Series         : " + volumeSeries +
                "\nMangaka         : " + mangaka;
    }
}

