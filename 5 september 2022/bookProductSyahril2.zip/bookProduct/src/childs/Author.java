package childs;

import parent.Person;

public class Author extends Person {
    //Construktor
    public Author(String firstName, String lastName, String country, int age) {
        super(firstName, lastName, country, age);
    }

}
