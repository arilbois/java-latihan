package childs;
import childs.Novelis;

import parent.BookProduct;
import parent.Person;
public class Novel extends Book {
    String genre;
    Novelis novelis;
    //Construktor

    public Novel(String bookCode, String title, Novelis novelis, Publisher publisher, String genre) {
        super(bookCode, title, novelis, publisher);
        this.genre = genre;
        this.novelis = novelis;
        calculatePrice();
    }

    private void calculatePrice() {
        double percen;
        if (novelis.getRating().equalsIgnoreCase("New Commer")) {
            percen = 1.25;
        } else if (novelis.getRating().equalsIgnoreCase("Good")) {
            percen =  1.35;
        } else {
            percen = 1.5;
        }
        this.setPrice(getPublisher().getProductionCost() * percen);
    }
    //Getter
    public String getGenre() {
        return genre;
    }
    public void getDetailNovel(String author, String publisher) {
        System.out.println("Novelis          : "+author);
        System.out.println("Book Code        : "+getBookCode());
        System.out.println("Title            : "+getTitle());
        System.out.println("Genre            : "+getGenre());
        System.out.println("Rating           : "+novelis.getRating());
        System.out.println("Publiser         : "+publisher);
        System.out.println("Price            : "+indonesiaCurrency());
        System.out.println("location         : "+getPerson().getCountry());
        System.out.println("===================================");
    }

    @Override
    public String toString() {
        return "Genre         : " + getGenre() +
                "\nnovelis         : " + novelis;
    }
}
