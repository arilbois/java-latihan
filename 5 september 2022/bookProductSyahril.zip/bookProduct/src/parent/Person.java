package parent;

public class Person {
    String firstName, lastName, country;
    int age;

    public Person(String firstName, String lastName, String country, int age) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.country = country;
        this.age = age;
    }
    @Override
    public String toString() {
        return super.toString();
    }
    public String getCountry() {
        return country;
    }
    public String getFullName(){
        return firstName + " " + lastName;
    }
}
