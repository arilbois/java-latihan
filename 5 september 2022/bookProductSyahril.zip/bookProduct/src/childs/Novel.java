package childs;

import parent.BookProduct;
import parent.Person;

public class Novel extends BookProduct {
    String genre;
    public Novel(String bookCode, String title, Person person, Publisher publisher, String genre) {
        super(bookCode, title, person, publisher);
        this.genre = genre;
        calculatePrice();
    }
    Novelis novelis = (Novelis) getPerson();
    private void calculatePrice() {
        double percen;
        if (novelis.getRating().equalsIgnoreCase("New Commer")) {
            percen = 1.25;
        } else if (novelis.getRating().equalsIgnoreCase("Good")) {
            percen =  1.35;
        } else {
            percen = 1.5;
        }
        this.setPrice(getPublisher().getProductionCost() * percen);
    }
    public String getGenre() {
        return genre;
    }
    public void getDetailNovel(String author, String publisher) {
        System.out.println("Novelis          : "+author);
        System.out.println("Book Code        : "+getBookCode());
        System.out.println("Title            : "+getTitle());
        System.out.println("Genre            : "+getGenre());
        System.out.println("Rating           : "+novelis.getRating());
        System.out.println("Publiser         : "+publisher);
        System.out.println("Price            : "+indonesiaCurrency(getPrice()));
        System.out.println("location         : "+getPerson().getCountry());
        System.out.println("===================================");
    }
}
