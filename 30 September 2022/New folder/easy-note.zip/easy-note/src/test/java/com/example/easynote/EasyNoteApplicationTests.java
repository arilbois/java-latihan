package com.example.easynote;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EasyNoteApplicationTests {

	@Test
	void contextLoads() {
	}

}
